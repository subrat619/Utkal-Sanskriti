package com.cyfrifpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtkalSanskritiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
