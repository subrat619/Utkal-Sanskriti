package com.cyfrifpro.service;

import java.util.List;

import com.cyfrifpro.dto.CreatedUsersResponseDTO;
import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.dto.UserUpdateDTO;

public interface UserManagementService {
	// Method that fetches users by creator and role
	CreatedUsersResponseDTO getCreatedUsersByCreatorAndRole(Long creatorId, String role);

	// Method to get count of users created by the given creator
	long getCreatedUsersCountByCreator(Long creatorId);

	// Method to fetch all users created by a given creator
	List<UserDTO> getUsersCreatedBy(Long creatorId);

	List<UserDTO> getCreatedUsersHierarchy(Long parentId);

	void deleteUserById(Long id);

	UserDTO updateUser(Long id, UserUpdateDTO userUpdateDTO);

}
