package com.cyfrifpro.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cyfrifpro.dto.RoleCountDTO;
import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.exception.ResourceNotFoundException;
import com.cyfrifpro.mapper.UserMapper;
import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;
import com.cyfrifpro.service.UserService2;

@Service
public class UserServiceImpl implements UserService2 {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserMapper userMapper;

	@Override
	public UserDTO getMasterAdminById(Long id) {
		User masterAdmin = userRepository.findById(id).filter(user -> "MASTER_ADMIN".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("Master Admin is not found in id: " + id));
		return userMapper.toDTO(masterAdmin);
	}

	@Override
	public List<UserDTO> getAllMasterAdmins() {
		return userRepository.findAll().stream().filter(user -> "MASTER_ADMIN".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getAdminById(Long id) {
		User admin = userRepository.findById(id).filter(user -> "ADMIN".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("Admin is not found with ID: " + id));
		return userMapper.toDTO(admin);
	}

	@Override
	public List<UserDTO> getAllAdmins() {
		return userRepository.findAll().stream().filter(user -> "ADMIN".equals(user.getRole())).map(userMapper::toDTO)
				.collect(Collectors.toList());
	}

	@Override
	public UserDTO getTopLevelById(Long id) {
		User topLevel = userRepository.findById(id).filter(user -> "TOP_LEVEL".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("TOP LEVEL user is not found with id: " + id));
		return userMapper.toDTO(topLevel);
	}

	@Override
	public List<UserDTO> getAllTopLevels() {
		return userRepository.findAll().stream().filter(user -> "TOP_LEVEL".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getMidlevelById(Long id) {
		User midLevel = userRepository.findById(id).filter(user -> "MID_LEVEL".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("MID LEVEL user is not found with id: " + id));
		return userMapper.toDTO(midLevel);
	}

	@Override
	public List<UserDTO> getAllMidlevels() {
		return userRepository.findAll().stream().filter(user -> "MID_LEVEL".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getLowlevelById(Long id) {
		User lowLevel = userRepository.findById(id).filter(user -> "LOW_LEVEL".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("LOW LEVEL user is not found with id: " + id));
		return userMapper.toDTO(lowLevel);
	}

	@Override
	public List<UserDTO> getAllLowlevels() {
		return userRepository.findAll().stream().filter(user -> "LOW_LEVEL".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getSupportServiceById(Long id) {
		User supportService = userRepository.findById(id).filter(user -> "SUPPORT_SERVICE".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("SUPPORT SERVICE user not is found with id: " + id));
		return userMapper.toDTO(supportService);
	}

	@Override
	public List<UserDTO> getAllSupportServices() {
		return userRepository.findAll().stream().filter(user -> "SUPPORT_SERVICE".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getManagmentGovermentById(Long id) {
		User managmentGoverment = userRepository.findById(id).filter(user -> "MANAGEMENT_GOV".equals(user.getRole()))
				.orElseThrow(
						() -> new ResourceNotFoundException("MANAGEMENT GOVERMENT user is not found with id: " + id));
		return userMapper.toDTO(managmentGoverment);
	}

	@Override
	public List<UserDTO> getAllManagmentGoverments() {
		return userRepository.findAll().stream().filter(user -> "MANAGEMENT_GOV".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getGovermentById(Long id) {
		User goverment = userRepository.findById(id).filter(user -> "GOV".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("GOVERMENT is not found with id: " + id));
		return userMapper.toDTO(goverment);
	}

	@Override
	public List<UserDTO> getAllGoverments() {
		return userRepository.findAll().stream().filter(user -> "GOV".equals(user.getRole())).map(userMapper::toDTO)
				.collect(Collectors.toList());
	}

	@Override
	public UserDTO getTempleAdminById(Long id) {
		User templeAdmin = userRepository.findById(id).filter(user -> "TEMP_ADMIN".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("TEMP ADMIN is not found with id: " + id));
		return userMapper.toDTO(templeAdmin);
	}

	@Override
	public List<UserDTO> getAllTempleAdmins() {
		return userRepository.findAll().stream().filter(user -> "TEMP_ADMIN".equals(user.getRole()))
				.map(userMapper::toDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO getGuideById(Long id) {
		User guide = userRepository.findById(id).filter(user -> "GUIDE".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("GUIDE is not found with id: " + id));
		return userMapper.toDTO(guide);
	}

	@Override
	public List<UserDTO> getAllGuides() {
		return userRepository.findAll().stream().filter(user -> "GUIDE".equals(user.getRole())).map(userMapper::toDTO)
				.collect(Collectors.toList());
	}

	@Override
	public UserDTO getClientById(Long id) {
		User client = userRepository.findById(id).filter(user -> "CLIENT".equals(user.getRole()))
				.orElseThrow(() -> new ResourceNotFoundException("Client is not found with ID: " + id));
		return userMapper.toDTO(client);
	}

	@Override
	public List<UserDTO> getAllClients() {
		return userRepository.findAll().stream().filter(user -> "CLIENT".equals(user.getRole())).map(userMapper::toDTO)
				.collect(Collectors.toList());
	}

	@Override
	public List<RoleCountDTO> getTotalUsersByRole() {
		List<RoleCountDTO> roleCounts = new ArrayList<>();

		roleCounts.add(new RoleCountDTO("MASTER_ADMIN", userRepository.countMasterAdmins()));
		roleCounts.add(new RoleCountDTO("ADMIN", userRepository.countAdmins()));
		roleCounts.add(new RoleCountDTO("TOP_LEVEL", userRepository.countTopLevel()));
		roleCounts.add(new RoleCountDTO("MID_LEVEL", userRepository.countMidLevel()));
		roleCounts.add(new RoleCountDTO("MANAGEMENT_GOV", userRepository.countManagementGov()));
		roleCounts.add(new RoleCountDTO("LOW_LEVEL", userRepository.countLowLevel()));
		roleCounts.add(new RoleCountDTO("GOV", userRepository.countGoverment()));
		roleCounts.add(new RoleCountDTO("SUPPORT_SERVICE", userRepository.countSuportService()));
		roleCounts.add(new RoleCountDTO("TEMP_ADMIN", userRepository.countTempleAdmin()));
		roleCounts.add(new RoleCountDTO("GUIDE", userRepository.countGuide()));
		roleCounts.add(new RoleCountDTO("CLIENT", userRepository.countClients()));

		return roleCounts;
	}

	@Override
	public Map<String, Map<String, Object>> getCountAndListOfUsersByRole() {
		List<Object[]> countResult = userRepository.countUsersByRole();
		Map<String, Map<String, Object>> roleUserMap = new HashMap<>();

		for (Object[] obj : countResult) {
			String role = (String) obj[0];
			Long count = (Long) obj[1];
			List<User> users = userRepository.findByRole(role);

			Map<String, Object> userDetails = new HashMap<>();
			userDetails.put("count", count);
			userDetails.put("users", users);

			roleUserMap.put(role, userDetails);
		}

		return roleUserMap;
	}

}
