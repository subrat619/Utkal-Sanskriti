package com.cyfrifpro.service;

import java.util.List;
import java.util.Map;

import com.cyfrifpro.dto.RoleCountDTO;
import com.cyfrifpro.dto.UserDTO;

public interface UserService2 {
	UserDTO getMasterAdminById(Long id);
	List<UserDTO> getAllMasterAdmins();
	
	UserDTO getAdminById(Long id);
	List<UserDTO> getAllAdmins();
    
	UserDTO getTopLevelById(Long id);
	List<UserDTO> getAllTopLevels();
    
    UserDTO getMidlevelById(Long id);
    List<UserDTO> getAllMidlevels();
    
    UserDTO getLowlevelById(Long id);
    List<UserDTO> getAllLowlevels();
    
    UserDTO getSupportServiceById(Long id);
    List<UserDTO> getAllSupportServices();
    
    UserDTO getManagmentGovermentById(Long id);
    List<UserDTO> getAllManagmentGoverments();
    
    UserDTO getGovermentById(Long id);
    List<UserDTO> getAllGoverments();
    
    UserDTO getTempleAdminById(Long id);
    List<UserDTO> getAllTempleAdmins();
    
    UserDTO getGuideById(Long id);
    List<UserDTO> getAllGuides();
    
    UserDTO getClientById(Long id);
    List<UserDTO> getAllClients();
    
    List<RoleCountDTO> getTotalUsersByRole();
    
    Map<String, Map<String, Object>> getCountAndListOfUsersByRole();

}
