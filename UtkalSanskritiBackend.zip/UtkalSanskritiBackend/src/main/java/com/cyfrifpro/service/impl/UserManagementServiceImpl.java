package com.cyfrifpro.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cyfrifpro.dto.CreatedUsersResponseDTO;
import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.dto.UserUpdateDTO;
import com.cyfrifpro.exception.ResourceNotFoundException;
import com.cyfrifpro.mapper.UserMapper;
import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;
import com.cyfrifpro.service.UserManagementService;

@Service
public class UserManagementServiceImpl implements UserManagementService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserMapper userMapper;

	// Method that fetches users by creator and role
	@Override
	public CreatedUsersResponseDTO getCreatedUsersByCreatorAndRole(Long creatorId, String role) {
		// Retrieve the creator user; throw exception if not found
		User creator = userRepository.findById(creatorId)
				.orElseThrow(() -> new ResourceNotFoundException("Creator with id " + creatorId + " not found"));

		// Fetch the users created by the creator with the specified role
		List<User> createdUsers = userRepository.findByCreatedByAndRole(creator, role);
		long count = userRepository.countByCreatedByAndRole(creator, role);

		// Convert entities to DTOs
		List<UserDTO> createdUserDTOs = createdUsers.stream().map(userMapper::toDTO).collect(Collectors.toList());

		// Build the response DTO
		CreatedUsersResponseDTO responseDTO = new CreatedUsersResponseDTO();
		responseDTO.setCount(count);
		responseDTO.setUsers(createdUserDTOs);

		return responseDTO;
	}

	// Method to get count of users created by the given creator
	@Override
	public long getCreatedUsersCountByCreator(Long creatorId) {
		// Retrieve the creator; throw exception if not found.
		User creator = userRepository.findById(creatorId)
				.orElseThrow(() -> new ResourceNotFoundException("Creator with id " + creatorId + " not found"));

		// Return the count of all users created by this creator.
		return userRepository.countByCreatedBy(creator);
	}

	// Method to fetch all users created by a given creator
	@Override
	public List<UserDTO> getUsersCreatedBy(Long creatorId) {
		// Retrieve the creator; throw exception if not found
		User creator = userRepository.findById(creatorId)
				.orElseThrow(() -> new ResourceNotFoundException("Creator with id " + creatorId + " not found"));

		// Fetch users created by this creator
		List<User> createdUsers = userRepository.findByCreatedBy(creator);

		// Map the entities to DTOs and return
		return createdUsers.stream().map(userMapper::toDTO).collect(Collectors.toList());
	}

	// Method to fetch all chield roles under parent role
	@Override
	public List<UserDTO> getCreatedUsersHierarchy(Long parentId) {
		User parentUser = userRepository.findById(parentId)
				.orElseThrow(() -> new ResourceNotFoundException("Parent user not found with id: " + parentId));

		return getRecursiveHierarchy(parentUser);
	}

	private List<UserDTO> getRecursiveHierarchy(User parentUser) {
		// Fetch users created by this parent
		List<User> createdUsers = userRepository.findByCreatedBy_Id(parentUser.getId());

		List<UserDTO> result = new ArrayList<>();
		for (User user : createdUsers) {
			// Recursively fetch the users created by this user
			UserDTO userDTO = userMapper.toDTO(user);
			userDTO.setCreatedUsers(getRecursiveHierarchy(user));
			result.add(userDTO);
		}

		return result;
	}

	@Override
	public void deleteUserById(Long id) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
		userRepository.deleteById(id);
	}

	@Override
	public UserDTO updateUser(Long id, UserUpdateDTO userUpdateDTO) {
		User existingUser = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

		// Update fields using mapper
		userMapper.updateUserFromDTO(userUpdateDTO, existingUser);

		// Save updated user
		User updatedUser = userRepository.save(existingUser);

		// Return updated user as DTO
		return userMapper.toDTO(updatedUser);
	}

}
