package com.cyfrifpro.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class TokenBlacklistService {

    // Store invalidated tokens and their invalidation time
    private Map<String, Long> invalidTokens = new HashMap<>();

    // Invalidate the token by storing it with the current time
    public void invalidateToken(String token) {
        invalidTokens.put(token, System.currentTimeMillis());
    }

    // Check if the token is invalidated
    public boolean isTokenInvalid(String token) {
        return invalidTokens.containsKey(token);
    }

    // Remove expired tokens (older than 24 hours for example)
    public void removeExpiredTokens() {
        long currentTime = System.currentTimeMillis();
        long expirationThreshold = 24 * 60 * 60 * 1000;  // 24 hours in milliseconds
        
        invalidTokens.entrySet().removeIf(entry -> (currentTime - entry.getValue()) > expirationThreshold);
    }
}
