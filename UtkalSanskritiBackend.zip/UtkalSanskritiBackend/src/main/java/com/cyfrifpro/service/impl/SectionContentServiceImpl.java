package com.cyfrifpro.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cyfrifpro.dto.SectionContentRequestDTO;
import com.cyfrifpro.dto.SectionContentResponseDTO;
import com.cyfrifpro.exception.ResourceNotFoundException;
import com.cyfrifpro.mapper.SectionContentMapper;
import com.cyfrifpro.model.SectionContent;
import com.cyfrifpro.repository.SectionContentRepository;
import com.cyfrifpro.service.SectionContentService;

@Service
public class SectionContentServiceImpl implements SectionContentService {

//	@Autowired
	private final SectionContentRepository sectionContentRepository;

//    @Autowired
	public SectionContentServiceImpl(SectionContentRepository sectionContentRepository) {
		this.sectionContentRepository = sectionContentRepository;
	}

	@Value("${image.upload.dir}")
	private String uploadDir;

//	@Override
//	public SectionContentResponseDTO addContent(SectionContentRequestDTO dto, MultipartFile image) throws IOException {
//		// Save image to disk
//		String fileName = System.currentTimeMillis() + "_" + image.getOriginalFilename();
//		Path filePath = Paths.get(uploadDir, fileName);
//		Files.copy(image.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
//
//		// Save in DB
//		SectionContent content = new SectionContent();
//		content.setSectionHeader(dto.getSectionHeader());
//		content.setImagePath(fileName);
//		content.setImageText(dto.getImageText());
//		sectionContentRepository.save(content);
//
//		return SectionContentMapper.toDTO(content);
//	}

	@Override
	public SectionContentResponseDTO addContent(SectionContentRequestDTO dto) throws IOException {
		// Create new SectionContent from the DTO data
		SectionContent content = new SectionContent();
		content.setSectionHeader(dto.getSectionHeader());
		// Instead of saving a file, we use the provided image URL (or file name)
		content.setImagePath(dto.getImageUrl());
		content.setImageText(dto.getImageText());

		sectionContentRepository.save(content);
		return SectionContentMapper.toDTO(content);
	}

	@Override
	public List<SectionContentResponseDTO> getAllContent() {
		return sectionContentRepository.findAll().stream().map(SectionContentMapper::toDTO)
				.collect(Collectors.toList());
	}

	@Override
	public SectionContentResponseDTO updateContent(Long id, SectionContentRequestDTO dto) {
		SectionContent content = sectionContentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Content not found"));

		if (dto.getSectionHeader() != null)
			content.setSectionHeader(dto.getSectionHeader());
		if (dto.getImageText() != null)
			content.setImageText(dto.getImageText());

		sectionContentRepository.save(content);
		return SectionContentMapper.toDTO(content);
	}

	@Override
	public void deleteContent(Long id) {
		SectionContent content = sectionContentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Content not found"));

		Path filePath = Paths.get(uploadDir, content.getImagePath());
		try {
			Files.deleteIfExists(filePath);
		} catch (IOException ignored) {
		}

		sectionContentRepository.delete(content);
	}
}
