package com.cyfrifpro.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;

@Service
public class UserService {

    // The map defining the required parent roles for each role
    private static final Map<String, String> REQUIRED_PARENT_ROLE = Map.of(
        "ADMIN", "MASTER_ADMIN",
        "TOP_LEVEL", "ADMIN",
        "MID_LEVEL", "TOP_LEVEL",
        "MANAGEMENT_GOV", "TOP_LEVEL",
        "LOW_LEVEL", "MID_LEVEL",
        "SUPPORT_SERVICE", "LOW_LEVEL",
        "GOV", "MANAGEMENT_GOV",
        "TEMP_ADMIN", "GOV",
        "GUIDE", "TEMP_ADMIN"
    );

    // List of roles allowed to create "Client" users
    private static final List<String> ALLOWED_ROLES_TO_CREATE_CLIENT = List.of("SUPPORT_SERVICE", "GUIDE");

    @Autowired
    private UserRepository userRepository;

    // Check if the current user can create a new user with the specified role
    public boolean canCreateRole(User currentUser, UserDTO newUserDTO) {
        String newUserRole = newUserDTO.getRole();

        // Allow Client role to be created by SUPPORT_SERVICE or GUIDE roles
        if ("CLIENT".equals(newUserRole) && ALLOWED_ROLES_TO_CREATE_CLIENT.contains(currentUser.getRole())) {
            return true;
        }

        // First registration: MASTER_ADMIN can be created by any user without a check
        if ("MASTER_ADMIN".equals(newUserRole) && newUserDTO.getCreatedBy() == null) {
            return true;
        }

        // Get required parent role for the new user role
        String requiredParentRole = REQUIRED_PARENT_ROLE.get(newUserRole);

        // If no parent role is defined, creation is not allowed
        if (requiredParentRole == null) {
            return false;
        }

        // Check if the creator's role matches the required parent role
        String creatorRole = currentUser.getRole();
        return requiredParentRole.equals(creatorRole);
    }

 // Register a new user
    public User registerUser(UserDTO newUserDTO) {
        // Check if a MASTER_ADMIN already exists
        if ("MASTER_ADMIN".equals(newUserDTO.getRole())) {
            long masterAdminCount = userRepository.countByRole("MASTER_ADMIN");
            if (masterAdminCount > 0) {
                throw new RuntimeException("A MASTER_ADMIN already exists. Only one MASTER_ADMIN can be registered.");
            }
        }

        User newUser = new User();
        newUser.setUserName(newUserDTO.getUserName());
        newUser.setPassword(newUserDTO.getPassword());
        newUser.setEmail(newUserDTO.getEmail());
        newUser.setContactNumber(newUserDTO.getContactNumber());
        newUser.setRole(newUserDTO.getRole());

        // For MASTER_ADMIN and CLIENT, 'createdBy' should be null
        if ("MASTER_ADMIN".equals(newUserDTO.getRole()) || "CLIENT".equals(newUserDTO.getRole())) {
            newUser.setCreatedBy(null);
        } else {
            // For other roles, ensure 'createdBy' is set and valid
            if (newUserDTO.getCreatedBy() == null) {
                throw new RuntimeException("The createdBy field is required for non-MASTER_ADMIN and non-CLIENT users.");
            }

            User createdBy = userRepository.findById(newUserDTO.getCreatedBy())
                                           .orElseThrow(() -> new RuntimeException("Creator user not found"));

            // Ensure the creator's role matches the required parent role
            String requiredParentRole = REQUIRED_PARENT_ROLE.get(newUserDTO.getRole());
            if (requiredParentRole != null && !requiredParentRole.equals(createdBy.getRole())) {
                throw new RuntimeException("The creator does not have permission to create this role.");
            }

            newUser.setCreatedBy(createdBy);
        }

        return userRepository.save(newUser);
    }

}
