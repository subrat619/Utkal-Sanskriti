package com.cyfrifpro.service;

import java.util.Optional;
//import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cyfrifpro.config.UserInfoConfig;
import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;

//import java.util.HashMap;
//import java.util.Map;
//import java.util.Random;

@Service
public class UserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Try to load the user as a Admin if the Client and the Manager is not found
		Optional<User> user = userRepository.findByUserName(username);
		if (user.isPresent()) {
			return new UserInfoConfig(user.get()); // Use UserInfoConfig for Client
		}

		// If neither is found, throw exception
		throw new UsernameNotFoundException("User not found with user name: " + username);
	}

}


