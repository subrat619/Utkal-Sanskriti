package com.cyfrifpro.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cyfrifpro.dto.SectionContentRequestDTO;
import com.cyfrifpro.dto.SectionContentResponseDTO;

public interface SectionContentService {
//	SectionContentResponseDTO addContent(SectionContentRequestDTO dto, MultipartFile image) throws IOException;
	SectionContentResponseDTO addContent(SectionContentRequestDTO dto) throws IOException;

	List<SectionContentResponseDTO> getAllContent();

	SectionContentResponseDTO updateContent(Long id, SectionContentRequestDTO dto);

	void deleteContent(Long id);
}
