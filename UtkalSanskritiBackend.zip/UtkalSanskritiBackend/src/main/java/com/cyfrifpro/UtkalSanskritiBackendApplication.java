package com.cyfrifpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackages = "com.cyfrifpro")
//@OpenAPIDefinition(info = @Info(title = "GrandSpace Application", version = "1.0.0", description = "This application is mainly used to manage the construction sites"), servers = @Server(url = "http://localhost:9090", description = "This is the url by using we can access the clients and managers"))
@EnableAsync
@EnableScheduling 
public class UtkalSanskritiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtkalSanskritiBackendApplication.class, args);
	}

}
