package com.cyfrifpro.mapper;

import com.cyfrifpro.dto.SectionContentResponseDTO;
import com.cyfrifpro.model.SectionContent;

public class SectionContentMapper {

	public static SectionContentResponseDTO toDTO(SectionContent content) {
		SectionContentResponseDTO dto = new SectionContentResponseDTO();
		dto.setId(content.getId());
		dto.setSectionHeader(content.getSectionHeader());
		dto.setImageUrl("/assets/" + content.getImagePath());
		dto.setImageText(content.getImageText());
		return dto;
	}
}
