package com.cyfrifpro.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.dto.UserUpdateDTO;
import com.cyfrifpro.model.User;

@Mapper(componentModel = "spring")
public interface UserMapper {

    // Map 'createdBy' from a User object to a Long (its id)
    @Mapping(source = "createdBy", target = "createdBy")
    UserDTO toDTO(User user);

    // Map 'createdBy' from a Long (id) to a User object
    @Mapping(source = "createdBy", target = "createdBy")
    User toEntity(UserDTO userDTO);
    
    void updateUserFromDTO(UserUpdateDTO dto, @MappingTarget User entity);

    // Custom method to convert a User object to its id (Long)
    default Long map(User user) {
        return user == null ? null : user.getId();
    }

    List<UserDTO> toDTOList(List<User> users);


    // Custom method to convert a Long id to a User object.
    // This creates a new User with only the id set.
    default User map(Long id) {
        if (id == null) {
            return null;
        }
        User user = new User();
        user.setId(id);
        return user;
    }
}
