package com.cyfrifpro.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cyfrifpro.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	Optional<User> findByUserName(String userName);

	User findByEmail(String email);

	long countByRole(String role);

	List<User> findByCreatedByAndRole(User createdBy, String role);

	long countByCreatedByAndRole(User createdBy, String role);

	long countByCreatedBy(User createdBy);

	List<User> findByCreatedBy(User createdBy);

	List<User> findByCreatedBy_Id(Long createdById);

	// Count roles
	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'MASTER_ADMIN'")
	Long countMasterAdmins();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'ADMIN'")
	Long countAdmins();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'TOP_LEVEL'")
	Long countTopLevel();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'MID_LEVEL'")
	Long countMidLevel();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'MANAGEMENT_GOV'")
	Long countManagementGov();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'LOW_LEVEL'")
	Long countLowLevel();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'GOV'")
	Long countGoverment();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'SUPPORT_SERVICE'")
	Long countSuportService();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'TEMP_ADMIN'")
	Long countTempleAdmin();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'GUIDE'")
	Long countGuide();

	@Query("SELECT COUNT(u) FROM User u WHERE u.role = 'CLIENT'")
	Long countClients();

	// Listing of all roles
	@Query("SELECT u.role, COUNT(u) FROM User u GROUP BY u.role")
	List<Object[]> countUsersByRole();

	List<User> findByRole(String role);
	
	void deleteById(Long id);

}
