package com.cyfrifpro.util;

public class OtpGenerator {
    public static String generateOtp() {
        int otp = 1000 + (int) (Math.random() * 9000);
        return String.valueOf(otp);
    }
}

