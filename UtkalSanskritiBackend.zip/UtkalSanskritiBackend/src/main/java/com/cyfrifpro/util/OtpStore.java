package com.cyfrifpro.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

@Component
public class OtpStore {
    private final Map<String, String> otpMap = new ConcurrentHashMap<>();
    private final Map<String, Long> otpExpiryMap = new ConcurrentHashMap<>();

    public void storeOtp(String email, String otp) {
        otpMap.put(email, otp);
        otpExpiryMap.put(email, System.currentTimeMillis() + (5 * 60 * 1000)); // 5 minutes expiration
    }

    public String getOtp(String email) {
        Long expiryTime = otpExpiryMap.get(email);
        if (expiryTime == null || System.currentTimeMillis() > expiryTime) {
            otpMap.remove(email);
            otpExpiryMap.remove(email);
            return null;
        }
        return otpMap.get(email);
    }

    public void removeOtp(String email) {
        otpMap.remove(email);
        otpExpiryMap.remove(email);
    }
}
