package com.cyfrifpro.config.security;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.cyfrifpro.service.TokenBlacklistService;

import jakarta.annotation.PostConstruct;

@Component
public class JWTUtil {

    @Value("${jwt.secret}")  // ✅ Ensure this matches the application.properties key
    private String secret;

    @Autowired
    private TokenBlacklistService tokenBlacklistService;
    
    @PostConstruct
    public void init() {
        System.out.println("🔹 JWT Secret Loaded: " + (secret != null ? "OK ✅" : "MISSING ❌"));
    }

    public String generateToken(Long id, String userName, String role) throws IllegalArgumentException, JWTCreationException {
        return JWT.create()
                .withSubject("User Details")
                .withClaim("id", id)
                .withClaim("userName", userName)
                .withClaim("role", role)
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 60))  // Set expiration time (1 hour in this case)
                .withIssuer("CyfrifPro Tech")
                .sign(Algorithm.HMAC256(secret));
    }


//    public Map<String, Object> validateTokenAndRetrieveClaims(String token) throws JWTVerificationException {
//        JWTVerifier verifier = JWT.require(Algorithm.HMAC256(secret))
//                .withSubject("User Details")
//                .withIssuer("CyfrifPro Tech")
//                .build();
//
//        DecodedJWT jwt = verifier.verify(token);
//
//        Map<String, Object> claims = new HashMap<>();
//        claims.put("id", jwt.getClaim("id").asLong());
//        claims.put("userName", jwt.getClaim("userName").asString());
//        claims.put("role", jwt.getClaim("role").asString());
//
//        return claims;
//    }

    public Map<String, Object> validateTokenAndRetrieveClaims(String token) throws JWTVerificationException {
        // Check if the token is invalidated
        if (tokenBlacklistService.isTokenInvalid(token)) {
            throw new JWTVerificationException("Token has been invalidated");
        }

        JWTVerifier verifier = JWT.require(Algorithm.HMAC256(secret))
                .withSubject("User Details")
                .withIssuer("CyfrifPro Tech")
                .build();

        DecodedJWT jwt = verifier.verify(token);

        Map<String, Object> claims = new HashMap<>();
        claims.put("id", jwt.getClaim("id").asLong());
        claims.put("userName", jwt.getClaim("userName").asString());
        claims.put("role", jwt.getClaim("role").asString());

        return claims;
    }
}
