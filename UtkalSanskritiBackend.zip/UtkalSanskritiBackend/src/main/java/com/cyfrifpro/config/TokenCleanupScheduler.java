package com.cyfrifpro.config;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cyfrifpro.service.TokenBlacklistService;

@Component
public class TokenCleanupScheduler {

    private final TokenBlacklistService tokenBlacklistService;

    public TokenCleanupScheduler(TokenBlacklistService tokenBlacklistService) {
        this.tokenBlacklistService = tokenBlacklistService;
    }

    // Schedule this method to run every 30 minutes
    @Scheduled(fixedRate = 30 * 60 * 1000) // 30 minutes
    public void cleanUpExpiredTokens() {
        tokenBlacklistService.removeExpiredTokens();
        System.out.println("Expired tokens cleaned up.");
    }
}

