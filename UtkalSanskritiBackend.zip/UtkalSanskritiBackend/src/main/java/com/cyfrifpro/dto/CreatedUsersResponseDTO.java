package com.cyfrifpro.dto;

import lombok.Data;
import java.util.List;

@Data
public class CreatedUsersResponseDTO {
	private long count;
	private List<UserDTO> users;
}
