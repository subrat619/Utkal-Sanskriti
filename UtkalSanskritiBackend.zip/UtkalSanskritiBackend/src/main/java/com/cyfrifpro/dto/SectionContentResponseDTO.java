package com.cyfrifpro.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SectionContentResponseDTO {

	private Long id;
	private String sectionHeader;
	private String imageUrl;
	private String imageText;
}
