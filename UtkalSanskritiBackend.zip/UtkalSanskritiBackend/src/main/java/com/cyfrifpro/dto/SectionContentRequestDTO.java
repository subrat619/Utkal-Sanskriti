package com.cyfrifpro.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SectionContentRequestDTO {

	@NotBlank(message = "Section header cannot be empty")
	private String sectionHeader;

	@Size(max = 500, message = "Image text should not exceed 500 characters")
	private String imageText;

	@NotBlank
	private String imageUrl; // Assuming this holds a URL or file name

}
