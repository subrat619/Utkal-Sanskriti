package com.cyfrifpro.dto;

import lombok.Data;

@Data
public class LoginDTO {
	
	private Long id;
	private String userName;
	private String password;

}
