package com.cyfrifpro.dto;

import java.util.List;

import lombok.Data;

@Data
public class UserDTO {

	private Long id;
    private String userName;
    private String email;
    private String contactNumber;
    private String password;
    private String role;
    private Long createdBy;
    private List<UserDTO> createdUsers;

}
