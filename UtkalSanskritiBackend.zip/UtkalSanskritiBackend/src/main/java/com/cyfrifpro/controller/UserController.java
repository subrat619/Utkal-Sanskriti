package com.cyfrifpro.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cyfrifpro.dto.RoleCountDTO;
import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.service.UserService2;

@RestController
@RequestMapping("/api/userDetails")
public class UserController {

	@Autowired
	private UserService2 userService2;

	// Endpoint to fetch master admin
	@GetMapping("/master")
	public List<UserDTO> getAllMasterAdmins() {
		return userService2.getAllMasterAdmins();
	}

	// Endpoint to get master admin by his id
	@GetMapping("/master/{id}")
	public UserDTO getMasterAdminById(@PathVariable Long id) {
		return userService2.getMasterAdminById(id);
	}

	// Endpoint to fetch all admins
	@GetMapping("/admins")
	public List<UserDTO> getAllAdmins() {
		return userService2.getAllAdmins();
	}

	// Endpoint to get admin by his id
	@GetMapping("/admins/{id}")
	public UserDTO getAdminById(@PathVariable Long id) {
		return userService2.getAdminById(id);
	}

	// Endpoint to fetch all top levele users
	@GetMapping("/topLevels")
	public List<UserDTO> getAllTopLevels() {
		return userService2.getAllTopLevels();
	}

	// Endpoint to get top level user by his id
	@GetMapping("/topLevels/{id}")
	public UserDTO getTopLevelById(@PathVariable Long id) {
		return userService2.getTopLevelById(id);
	}

	// Endpoint to fetch all mid level users
	@GetMapping("/midLevels")
	public List<UserDTO> getAllMidLevels() {
		return userService2.getAllMidlevels();
	}

	// Endpoint to get mid level user by his id
	@GetMapping("/midLevels/{id}")
	public UserDTO getMidLevelById(@PathVariable Long id) {
		return userService2.getMidlevelById(id);
	}

	// Endpoint to fetch all low levels users
	@GetMapping("/lowlevels")
	public List<UserDTO> getAllLowlevels() {
		return userService2.getAllLowlevels();
	}

	// Endpoint to get low level user by his id
	@GetMapping("/lowlevels/{id}")
	public UserDTO getLowlevelById(@PathVariable Long id) {
		return userService2.getLowlevelById(id);
	}

	// Endpoint to fetch all support service users
	@GetMapping("/supportServices")
	public List<UserDTO> getAllSupportServices() {
		return userService2.getAllSupportServices();
	}

	// Endpoint to get support service user by his id
	@GetMapping("/supportServices/{id}")
	public UserDTO getSupportServiceById(@PathVariable Long id) {
		return userService2.getSupportServiceById(id);
	}

	// Endpoint to fetch all goverment managment users
	@GetMapping("/managmentGoverments")
	public List<UserDTO> getAllManagmentGoverments() {
		return userService2.getAllManagmentGoverments();
	}

	// Endpoint to get goverment managment user by his id
	@GetMapping("/managmentGoverments/{id}")
	public UserDTO getManagmentGovermentById(@PathVariable Long id) {
		return userService2.getManagmentGovermentById(id);
	}

	// Endpoint to fetch all goverment users
	@GetMapping("/goverments")
	public List<UserDTO> getAllGoverments() {
		return userService2.getAllGoverments();
	}

	// Endpoint to get goverment user by his id
	@GetMapping("/goverments/{id}")
	public UserDTO getGovermentById(@PathVariable Long id) {
		return userService2.getGovermentById(id);
	}

	// Endpoint to fetch all temple admin users
	@GetMapping("/templeAdmins")
	public List<UserDTO> getAllTempleAdmins() {
		return userService2.getAllTempleAdmins();
	}

	// Endpoint to get temple admin by his id
	@GetMapping("/templeAdmins/{id}")
	public UserDTO getTempleAdminById(@PathVariable Long id) {
		return userService2.getTempleAdminById(id);
	}

	// Endpoint to fetch all guide users
	@GetMapping("/guides")
	public List<UserDTO> getAllGuides() {
		return userService2.getAllGuides();
	}

	// Endpoint to get guide by his id
	@GetMapping("/guides/{id}")
	public UserDTO getGuideById(@PathVariable Long id) {
		return userService2.getGuideById(id);
	}

	// Endpoint to fetch all clients
	@GetMapping("/clients")
	public List<UserDTO> getAllClients() {
		return userService2.getAllClients();
	}

	// Endpoint to get client by his id
	@GetMapping("/clients/{id}")
	public UserDTO getClientById(@PathVariable Long id) {
		return userService2.getClientById(id);
	}

	// Count all Roles
	@GetMapping("/roles/count")
	public ResponseEntity<List<RoleCountDTO>> getTotalUsersByRole() {
		List<RoleCountDTO> roleCounts = userService2.getTotalUsersByRole();
		return ResponseEntity.ok(roleCounts);
	}

	//Method for listing roles
	@GetMapping("/roles/count_with_allDetails")
	public ResponseEntity<Map<String, Map<String, Object>>> getCountAndListOfUsersByRole() {
	    Map<String, Map<String, Object>> result = userService2.getCountAndListOfUsersByRole();
	    return ResponseEntity.ok(result);
	}


}
