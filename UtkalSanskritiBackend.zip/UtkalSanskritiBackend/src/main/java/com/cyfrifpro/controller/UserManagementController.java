package com.cyfrifpro.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cyfrifpro.dto.CreatedUsersResponseDTO;
import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.dto.UserUpdateDTO;
import com.cyfrifpro.service.UserManagementService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users/managment")
public class UserManagementController {

	@Autowired
	private UserManagementService userManagementService;

	// Method that fetches users by creator and role
	@GetMapping("/{creatorId}/created_users/{role}")
	public ResponseEntity<CreatedUsersResponseDTO> getCreatedUsers(@PathVariable Long creatorId,
			@PathVariable String role) {
		CreatedUsersResponseDTO response = userManagementService.getCreatedUsersByCreatorAndRole(creatorId, role);
		return ResponseEntity.ok(response);
	}

	// Endpoint to get count of users created by the given creator
	@GetMapping("/{creatorId}/created_users/count")
	public ResponseEntity<Map<String, Long>> getCreatedUsersCount(@PathVariable Long creatorId) {
		long count = userManagementService.getCreatedUsersCountByCreator(creatorId);
		Map<String, Long> response = new HashMap<>();
		response.put("count", count);
		return ResponseEntity.ok(response);
	}

	// Endpoint to fetch all users created by a given creator
	@GetMapping("/{creatorId}/created_users")
	public ResponseEntity<List<UserDTO>> getUsersCreatedBy(@PathVariable Long creatorId) {
		List<UserDTO> createdUsers = userManagementService.getUsersCreatedBy(creatorId);
		return ResponseEntity.ok(createdUsers);
	}

	// Endpoint for geting all listing like tree structure
	@GetMapping("/{id}/created_users/lists")
	public ResponseEntity<List<UserDTO>> getCreatedUsersHierarchy(@PathVariable Long id) {
		List<UserDTO> hierarchy = userManagementService.getCreatedUsersHierarchy(id);
		return ResponseEntity.ok(hierarchy);
	}

	//Method for delete user!!!
	@DeleteMapping("/users_delete/{id}")
	public ResponseEntity<String> deleteUserById(@PathVariable Long id) {
		userManagementService.deleteUserById(id);
		return ResponseEntity.ok("User(id:"+id+") deleted successfully");
	}

	//Method for update the user info...
	@PutMapping("/user_update/{id}")
	public ResponseEntity<UserDTO> updateUser(
	        @PathVariable Long id,
	        @Valid @RequestBody UserUpdateDTO userUpdateDTO) {
	    UserDTO updatedUser = userManagementService.updateUser(id, userUpdateDTO);
	    return ResponseEntity.ok(updatedUser);
	}

}
