package com.cyfrifpro.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cyfrifpro.config.UserInfoConfig;
import com.cyfrifpro.config.security.JWTUtil;
import com.cyfrifpro.dto.ChangePasswordRequest;
import com.cyfrifpro.dto.LoginDTO;
import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;
import com.cyfrifpro.service.TokenBlacklistService;

@RestController
public class AuthController {
    
    @Autowired
	private JWTUtil jwtUtil;
    
    @Autowired
	private AuthenticationManager authenticationManager;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TokenBlacklistService tokenBlacklistService;

 // Login endpoint for Manager or Client
 	@PostMapping("/login")
 	public ResponseEntity<Map<String, Object>> loginHandler(@RequestBody LoginDTO credentials) {
 		try {
 			// Authenticate the user
 			UsernamePasswordAuthenticationToken authCredentials = new UsernamePasswordAuthenticationToken(
 					credentials.getUserName(), credentials.getPassword());
 			Authentication auth = authenticationManager.authenticate(authCredentials);

 			// Fetch authenticated user details
 			UserDetails userDetails = (UserDetails) auth.getPrincipal();
 			String userName = userDetails.getUsername();

 			// Retrieve the user's role
 			String roleName = userDetails.getAuthorities().stream().findFirst()
 					.map(authority -> authority.getAuthority().replace("ROLE_", "")).orElse("USER");

 			Optional<User> userOptional = userRepository.findByUserName(userName);
 			if (userOptional.isPresent()) {
 				User user = userOptional.get();
 				return generateTokenResponse(user.getId(), userName, roleName);
 			}

 			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
 					.body(Collections.singletonMap("error", "User not found"));

 		} catch (BadCredentialsException e) {
 			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
 					.body(Collections.singletonMap("error", "Invalid email or password"));
 		}
 	}

 	
 	private ResponseEntity<Map<String, Object>> generateTokenResponse(Long userId, String userName, String roleName) {
 		// Generate JWT token
 		String token = jwtUtil.generateToken(userId, userName, roleName);

 		// Create response
 		Map<String, Object> response = new HashMap<>();
 		response.put("jwt-token", token);
 		return ResponseEntity.ok(response);
 	}

 	@PostMapping("/change_password")
	public ResponseEntity<Map<String, String>> changePassword(@RequestBody ChangePasswordRequest request) {
	    try {
	    	
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	        // Get the authenticated user's email
	        String userName = request.getUserName();
	        String oldPassword = request.getOldPassword();
	        String newPassword = request.getNewPassword();

	        // Check if the user exists in any of the repositories
	        Optional<User> userOptional = userRepository.findByUserName(userName);

	        UserDetails userDetails = null;
	        if (userOptional.isPresent()) {
	            userDetails = new UserInfoConfig(userOptional.get());
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("error", "User not found"));
	        }

	        // Validate the old password
	        if (!passwordEncoder.matches(oldPassword, userDetails.getPassword())) {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Collections.singletonMap("error", "Incorrect old password"));
	        }

	        // Encrypt the new password
	        String encryptedPassword = passwordEncoder.encode(newPassword);

	        // Update the password in the respective repository
	        if (userOptional.isPresent()) {
	            User user = userOptional.get();
	            user.setPassword(encryptedPassword);
	            userRepository.save(user);
	        }

	        return ResponseEntity.ok(Collections.singletonMap("message", "Password changed successfully"));

	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("error", "An error occurred"));
	    }
	}
 	
 	@PostMapping("/logout_user")
    public ResponseEntity<String> invalidateToken(@RequestHeader("Authorization") String token) {
        // Remove the "Bearer " prefix if it exists
        token = token.replace("Bearer ", "");

        // Invalidate the token
        tokenBlacklistService.invalidateToken(token);

        return ResponseEntity.ok("Token invalidated successfully.");
    }
}
