package com.cyfrifpro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cyfrifpro.config.security.JWTUtil;
import com.cyfrifpro.dto.UserDTO;
import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;
import com.cyfrifpro.service.UserService;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class RegisterController {

	@Autowired
	private UserService userService;

	@Autowired
	private JWTUtil jwtUtil;

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody UserDTO newUserDTO) {
		// Create an instance of BCryptPasswordEncoder and encode the password
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(newUserDTO.getPassword());
		newUserDTO.setPassword(encodedPassword); // Set the encoded password back to the DTO

		// Allow Client to register without 'createdBy'
		if ("CLIENT".equals(newUserDTO.getRole())) {
			newUserDTO.setCreatedBy(null);
			try {
				userService.registerUser(newUserDTO);
				return ResponseEntity.ok("Client registered successfully");
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body("An error occurred while registering the client: " + e.getMessage());
			}
		}

		// Check if the creator is provided for roles that require it
		if (newUserDTO.getRole() != null && !"MASTER_ADMIN".equals(newUserDTO.getRole())
				&& newUserDTO.getCreatedBy() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body("The 'createdBy' field is required for non-MASTER_ADMIN and non-CLIENT roles.");
		}

		// For MASTER_ADMIN, no need to check 'createdBy'
		if ("MASTER_ADMIN".equals(newUserDTO.getRole()) && newUserDTO.getCreatedBy() != null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body("MASTER_ADMIN should not have a 'createdBy' field.");
		}

		try {
			// Get the current logged-in user (only for non-CLIENT roles)
			User currentUser = null;
			if (newUserDTO.getCreatedBy() != null) {
				currentUser = userRepository.findById(newUserDTO.getCreatedBy())
						.orElseThrow(() -> new UserNotFoundException("Creator user not found"));
			}

			// Only check the role hierarchy if the role is NOT CLIENT
			if (userService.canCreateRole(currentUser, newUserDTO)) {
				userService.registerUser(newUserDTO);
				return ResponseEntity.ok("User registered successfully");
			} else {
				return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You are not authorized to create this role");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("An error occurred while registering the user: " + e.getMessage());
		}
	}

	// Custom exception for user not found
	public class UserNotFoundException extends RuntimeException {
		public UserNotFoundException(String message) {
			super(message);
		}
	}
}
