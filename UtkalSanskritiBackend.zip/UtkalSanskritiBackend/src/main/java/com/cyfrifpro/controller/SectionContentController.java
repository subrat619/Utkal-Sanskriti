package com.cyfrifpro.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cyfrifpro.dto.SectionContentRequestDTO;
import com.cyfrifpro.dto.SectionContentResponseDTO;
import com.cyfrifpro.service.SectionContentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/section_content")
public class SectionContentController {

//	@Autowired
	private final SectionContentService sectionContentService;

	public SectionContentController(SectionContentService sectionContentService) {
		this.sectionContentService = sectionContentService;
	}

//	@PostMapping("/add")
//	public SectionContentResponseDTO addContent(@Valid @RequestParam("sectionHeader") String sectionHeader,
//	        @RequestParam("imageText") String imageText,
//	        @RequestParam("image") MultipartFile image)
//			throws IOException {
//
//		SectionContentRequestDTO dto = new SectionContentRequestDTO(sectionHeader, imageText);
//		return sectionContentService.addContent(dto, image);
//	}

	@PostMapping("/add")
	public SectionContentResponseDTO addContent(@Valid @RequestBody SectionContentRequestDTO dto) throws IOException {
		return sectionContentService.addContent(dto);
	}

	@GetMapping("/all")
	public List<SectionContentResponseDTO> getAllContent() {
		return sectionContentService.getAllContent();
	}

	@PatchMapping("/update/{id}")
	public SectionContentResponseDTO updateContent(@PathVariable Long id,
			@RequestBody @Valid SectionContentRequestDTO dto) {
		return sectionContentService.updateContent(id, dto);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteContent(@PathVariable Long id) {
		sectionContentService.deleteContent(id);
	}
}
