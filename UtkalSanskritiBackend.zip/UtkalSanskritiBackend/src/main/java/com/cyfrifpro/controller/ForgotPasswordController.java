package com.cyfrifpro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cyfrifpro.model.User;
import com.cyfrifpro.repository.UserRepository;
import com.cyfrifpro.service.EmailService;
import com.cyfrifpro.util.OtpGenerator;
import com.cyfrifpro.util.OtpStore;

@RestController
@RequestMapping("/auth")
public class ForgotPasswordController {
	
	@Autowired
    private BCryptPasswordEncoder passwordEncoder;

    private final UserRepository userRepository;
    private final EmailService emailService;
    private final OtpStore otpStore;

    public ForgotPasswordController(UserRepository userRepository, EmailService emailService, OtpStore otpStore) {
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.otpStore = otpStore;
    }

    // Step 1: Request OTP
    @PostMapping("/forgot_password")
    public ResponseEntity<String> forgotPassword(@RequestParam String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Email not registered.");
        }

        String otp = OtpGenerator.generateOtp();
        otpStore.storeOtp(email, otp);
        emailService.sendOtpEmail(email, otp);

        return ResponseEntity.ok("OTP sent to your email.");
    }

    // Step 2: Verify OTP and Reset Password
    @PostMapping("/reset_password")
    public ResponseEntity<String> resetPassword(@RequestParam String email, @RequestParam String otp, @RequestParam String newPassword) {
        String storedOtp = otpStore.getOtp(email);

        if (storedOtp == null || !storedOtp.equals(otp)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired OTP.");
        }

        User user = userRepository.findByEmail(email);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Email not registered.");
        }

        // Reset Password
        user.setPassword(passwordEncoder.encode(newPassword)); // Hash the password before saving in a real application
        userRepository.save(user);

        // Remove OTP after successful reset
        otpStore.removeOtp(email);

        return ResponseEntity.ok("Password successfully reset.");
    }
}

